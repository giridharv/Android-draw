package projects.android.giri.assignment3;

import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.DisplayMetrics;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;
import android.widget.Toast;

import java.util.ArrayList;
import android.view.GestureDetector;
import static android.graphics.Color.BLACK;
import static android.graphics.Color.BLUE;
import static android.graphics.Color.GREEN;
import static android.graphics.Color.RED;
import static projects.android.giri.assignment3.CircleView.heightOfView;
import static projects.android.giri.assignment3.CircleView.widthOfView;
import static projects.android.giri.assignment3.R.attr.height;

public class MenuActivity extends AppCompatActivity implements View.OnTouchListener{
//public boolean selected=true;
public static float initialPointX=0;// This variable is used to store point x  in onDown method
public static float initialPointY=0;// This variable is used to store point y in onDown method
    public static double changedPointX=0;
    public static double changedPointY=0;
    public static float plotX=0;// Used to store point x in onMove method
    public static float plotY=0;// Used to store point y in onMove method
    public static float radius=0;
    public static float updatedPointX=0;
    public static float updatedPointY=0;
    static ArrayList<Circle> pointList=new ArrayList<Circle>();
    static ArrayList<Circle> temporaryPointList=new ArrayList<Circle>();// This arraylist is used for storing circle objects when onDown is invoked
    static ArrayList<Circle> temporaryPointList1=new ArrayList<Circle>();// this arraylist is used for storing circle objects when onUp is invoked
    ArrayList<Circle> temporaryCirclesList1;// This arraylist is used for storing circle objects which were touched in onDown method and these are the circles we want to move
    Circle c1;
    static Paint pcolor;
    DisplayMetrics displayDimension;
    static int screenHeight,screenWidth;
    public static String modeOfCircle="Draw";
    public static float tempX=0;
    public static float tempY=0;
    public static float res=0;
    float movex=0;
    float movey =0;
    VelocityTracker velocity;
    Canvas tempcanvas;

    View touchView;
    private long hold;
    protected void onCreate(Bundle savedInstanceState)
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);

        touchView=findViewById(R.id.Touchview);
        touchView.setOnTouchListener(this);
        getSupportActionBar().setTitle("Drawing circle");
        //setOnTouchListener(this);
        //tempcanvas=(Canvas)findViewById(R.id.Touchview);
        pcolor=new Paint();
        pcolor.setColor(Color.BLACK);
        pcolor.setStyle(Paint.Style.STROKE);
        pcolor.setStrokeWidth(5);


    }
    @Override
    public boolean onPrepareOptionsMenu(Menu menu) {
        menu.clear();
        MenuInflater mnflater = getMenuInflater();

        mnflater.inflate(R.menu.options_menu, menu);
        return true;
    }



    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId())
        {
            case R.id.draw_circle:
                getSupportActionBar().setTitle("Drawing circle");
                System.out.println(item.getSubMenu());
                modeOfCircle="Draw";
                return true;
            case R.id.color_black:
                pcolor=new Paint();
                pcolor.setColor(Color.BLACK);
                pcolor.setStyle(Paint.Style.STROKE);
                pcolor.setStrokeWidth(5);
                Toast.makeText(this,"You want to paint black",Toast.LENGTH_LONG).show();
                return true;
            case R.id.color_blue:
                Toast.makeText(this,"You want to paint blue",Toast.LENGTH_LONG).show();
                pcolor=new Paint();
                pcolor.setColor(Color.BLUE);
                pcolor.setStyle(Paint.Style.STROKE);
                pcolor.setStrokeWidth(5);
                return true;
            case R.id.color_red:
                pcolor=new Paint();
                pcolor.setColor(Color.RED);
                pcolor.setStyle(Paint.Style.STROKE);
                pcolor.setStrokeWidth(5);
                Toast.makeText(this,"You want to paint red",Toast.LENGTH_LONG).show();
                return true;
            case R.id.color_green:
                pcolor=new Paint();
                pcolor.setColor(Color.GREEN);
                pcolor.setStyle(Paint.Style.STROKE);
                pcolor.setStrokeWidth(5);
                Toast.makeText(this,"You want to paint green",Toast.LENGTH_LONG).show();
                return true;
            case R.id.erase_circle:
                getSupportActionBar().setTitle("Delete circle");
                modeOfCircle="Erase";
                Toast.makeText(this,"You want to delete this circle",Toast.LENGTH_LONG).show();
                return true;
            case R.id.bounce_circle:
                getSupportActionBar().setTitle("Bounce circle");
                Toast.makeText(this,"You want to make this circle bounce",Toast.LENGTH_LONG).show();
                modeOfCircle="Move";
               //
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }

    }


    public boolean onTouch(View v, MotionEvent event) {
        if(event.getAction()==MotionEvent.ACTION_DOWN) {
            if (modeOfCircle == "Draw") {
                initialPointX = event.getX();
                initialPointY = event.getY();
                c1 = new Circle();
                c1.setCenterX(initialPointX);
                c1.setCenterY(initialPointY);
                c1.setX(initialPointX);
                c1.setY(initialPointY);
                c1.setColorSelected(pcolor);
                v.invalidate();
                return true;
            }
            else if(modeOfCircle=="Erase")
            {
                tempX = event.getX();
                tempY = event.getY();
                float storeX;
                float storeY;
                float storeRadius;
                float tempRadius;
                double tempX1;
                double tempY1;
                double tempres;

                for (int i = 0; i < pointList.size(); i++)
                {
                    storeX = pointList.get(i).getCenterX();
                    storeY = pointList.get(i).getCenterY();
                    storeRadius = pointList.get(i).getRadius();
                    tempX1 = tempX - storeX;
                    tempY1 = tempY - storeY;
                    tempX1 = Math.pow(tempX1, 2);
                    tempY1 = Math.pow(tempY1, 2);
                    tempres = tempX1 + tempY1;
                    tempRadius = (float) Math.sqrt(tempres);
                    if (tempRadius <= storeRadius) {

                        temporaryPointList.add(pointList.get(i));
                    }

                }
                return true;
            }
            else
            {
                velocity=VelocityTracker.obtain();
                velocity.addMovement(event);
                movex=event.getX();
                movey=event.getY();
                return true;

            }

        }
        else if(event.getAction()==MotionEvent.ACTION_MOVE)
        {
            if(modeOfCircle=="Draw")
            {
                plotX = event.getX();
                plotY = event.getY();
                c1.setX(plotX);
                c1.setY(plotY);
                changedPointX = plotX - initialPointX;
                changedPointY = plotY - initialPointY;
                changedPointX = Math.pow(changedPointX, 2);
                changedPointY = Math.pow(changedPointY, 2);
                double result = changedPointX + changedPointY;
                radius = (float) Math.sqrt(result);
                res=checkRadiusRange(radius);
                c1.setRadius(res);
                //c1.setRadius(radius);
                v.invalidate();
                return true;
            }
            else if(modeOfCircle=="Move")
            {


                velocity.addMovement(event);
                return true;
            }

        }
        else if(event.getAction()==MotionEvent.ACTION_UP)
        {
            if(modeOfCircle=="Draw")
            {
                updatedPointX = event.getX();
                updatedPointY = event.getY();
                c1.setX(updatedPointX);
                c1.setY(updatedPointY);
                changedPointX = updatedPointX - initialPointX;
                changedPointY = updatedPointY - initialPointY;
                changedPointX = Math.pow(changedPointX, 2);
                changedPointY = Math.pow(changedPointY, 2);
                double result = changedPointX + changedPointY;
                radius = (float) Math.sqrt(result);
                float res1=checkRadiusRange(radius);
                c1.setRadius(res1);
                c1.setVelocityOfX(0);
                c1.setVelocityOfY(0);
                c1.boundSet(7,widthOfView,7,heightOfView);
                //c1.setRadius(radius);


                pointList.add(c1);
                v.invalidate();
                return true;

            }
            else if(modeOfCircle=="Move")
            {
                velocity.addMovement(event);
                velocity.computeCurrentVelocity(1000);
                float tempvelocityx=velocity.getXVelocity();
                float tempvelocityy=velocity.getYVelocity();

                float stX;
                float stY;
                float stRadius;
                float temporaryRadius;
                double temporaryX1;
                double temporaryY1;
                double temporaryres;
                temporaryCirclesList1= new ArrayList<Circle>();
                for (int i = 0; i < pointList.size(); i++) {
                    stX = pointList.get(i).getCenterX();
                    stY = pointList.get(i).getCenterY();
                    stRadius = pointList.get(i).getRadius();
                    temporaryX1 = movex - stX;
                    temporaryY1 = movey - stY;
                    temporaryX1 = Math.pow(temporaryX1, 2);
                    temporaryY1 = Math.pow(temporaryY1, 2);
                    temporaryres = temporaryX1 + temporaryY1;
                    temporaryRadius = (float) Math.sqrt(temporaryres);
                    if (temporaryRadius <= stRadius)
                    {
                        //System.out.println(pointList.get(i));
                        temporaryCirclesList1.add(pointList.get(i));

                    }

                }
                for(Circle obj:temporaryCirclesList1)
                {
                    Circle referenceObj;
                    if(pointList.contains(obj))
                    {
                        referenceObj = pointList.get(pointList.indexOf(obj));
                        referenceObj.setVelocityOfX(tempvelocityx);
                        referenceObj.setVelocityOfY(tempvelocityy);

                    }
                }
                v.invalidate();
                //bounceCircle(50);
                return true;


            }
            else
            {
                float deletex=event.getX();
                float deletey=event.getY();
                float stX;
                float stY;
                float stRadius;
                float temporaryRadius;
                double temporaryX1;
                double temporaryY1;
                double temporaryres;
                for (int i = 0; i < pointList.size(); i++) {
                    stX = pointList.get(i).getCenterX();
                    stY = pointList.get(i).getCenterY();
                    stRadius = pointList.get(i).getRadius();
                    temporaryX1 = deletex - stX;
                    temporaryY1 = deletey - stY;
                    temporaryX1 = Math.pow(temporaryX1, 2);
                    temporaryY1 = Math.pow(temporaryY1, 2);
                    temporaryres = temporaryX1 + temporaryY1;
                    temporaryRadius = (float) Math.sqrt(temporaryres);
                    if (temporaryRadius <= stRadius)
                    {
                        temporaryPointList1.add(pointList.get(i));
                    }

                }
                temporaryPointList.retainAll(temporaryPointList1);
                for(Circle object:temporaryPointList)
                {
                    if(pointList.contains(object))
                    {
                        pointList.remove(object);
                    }
                }
                v.invalidate();
                return true;

            }

        }
        return true;
    }
    public float checkRadiusRange(float checkradius)
    {
        float leftHorizonDistance, rightHorizonDistance, topHorizonDistance, bottomHorizonDistance;
        leftHorizonDistance = initialPointX - 0;
        rightHorizonDistance = widthOfView - initialPointX;
        topHorizonDistance =  initialPointY - 0;
        bottomHorizonDistance = heightOfView - initialPointY;
        if(checkradius>leftHorizonDistance ||checkradius > rightHorizonDistance || checkradius > topHorizonDistance || checkradius > bottomHorizonDistance)
        {
            radius = Math.min(Math.min(leftHorizonDistance,rightHorizonDistance),Math.min(topHorizonDistance,bottomHorizonDistance));
            return radius;
        }
        return checkradius;// radius falls within the bounds range
    }





}
