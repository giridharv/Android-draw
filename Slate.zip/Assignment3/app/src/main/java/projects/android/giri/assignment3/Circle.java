package projects.android.giri.assignment3;

import android.graphics.Paint;

/**
 * Created by User on 2/20/2017.
 */

public class Circle
{
    private float x=0;
    private float y=0;
    private float leftBound,rightBound,topBound,bottomBound;
    public float getVelocityOfX() {
        return velocityOfX;
    }

    public void setVelocityOfX(float velocityOfX) {
        this.velocityOfX = velocityOfX;
    }

    private float velocityOfX=0;

    public float getVelocityOfY() {
        return velocityOfY;
    }

    public void setVelocityOfY(float velocityOfY) {
        this.velocityOfY = velocityOfY;
    }

    private float velocityOfY=0;

    public float getCenterX() {
        return centerX;
    }

    public void setCenterX(float centerX) {
        this.centerX = centerX;
    }

    private float centerX=0;

    public float getCenterY() {
        return centerY;
    }

    public void setCenterY(float centerY) {
        this.centerY = centerY;
    }

    private float centerY=0;
    Paint colorSelected;

    public Paint getColorSelected() {
        return colorSelected;
    }

    public void setColorSelected(Paint colorSelected) {
        this.colorSelected = colorSelected;
    }



    public float getRadius() {
        return radius;
    }

    public void setRadius(float radius) {
        this.radius = radius;
    }

    private float radius = 1;

    public float getX() {
        return x;
    }

    public void setX(float x) {
        this.x = x;
    }

    public float getY() {
        return y;
    }

    public void setY(float y) {
        this.y = y;
    }

   public void animate()
   {
       centerX= centerX+ velocityOfX;
       centerY=centerY+velocityOfY;

       velocityOfX=velocityOfX*(float)0.65;
       velocityOfY=velocityOfY*(float)0.65;

       if(Math.abs(velocityOfX)<1)
       {
           velocityOfX=0;
       }
       if(Math.abs(velocityOfY)<1)
       {
           velocityOfY=0;
       }
       checkIfCirclesCollideWithBounds();
   }
    public void checkIfCirclesCollideWithBounds()
    {
        if(centerY<topBound)
        {
            centerY=topBound;
            velocityOfY=velocityOfY*(-1);
        }
        else if(centerY>bottomBound)
        {
            centerY=bottomBound;
            velocityOfY=velocityOfY*(-1);
        }
        else if(centerX>rightBound)
        {
            centerX=rightBound;
            velocityOfX=velocityOfX*(-1);
        }
        else if(centerX<leftBound)
        {
            centerX=leftBound;
            velocityOfX=velocityOfX*(-1);
        }
    }
    public void boundSet(int leftbounds,int rightbounds,int topbounds,int bottombounds)
    {
        leftBound=leftbounds+radius;
        rightBound=rightbounds-radius;
        topBound= topbounds+radius;
        bottomBound=bottombounds-radius;

    }

}
