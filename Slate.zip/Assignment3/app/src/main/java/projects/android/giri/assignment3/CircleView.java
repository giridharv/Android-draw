package projects.android.giri.assignment3;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;


import java.util.Iterator;

import static projects.android.giri.assignment3.MenuActivity.initialPointX;
import static projects.android.giri.assignment3.MenuActivity.initialPointY;
import static projects.android.giri.assignment3.MenuActivity.modeOfCircle;
import static projects.android.giri.assignment3.MenuActivity.pcolor;
import static projects.android.giri.assignment3.MenuActivity.plotX;
import static projects.android.giri.assignment3.MenuActivity.plotY;
import static projects.android.giri.assignment3.MenuActivity.pointList;
import static projects.android.giri.assignment3.MenuActivity.radius;
import static projects.android.giri.assignment3.MenuActivity.res;
//import static projects.android.giri.assignment3.MenuActivity.res;

/**
 * Created by User on 2/19/2017.
 */
public class CircleView extends View implements Runnable
{
    static int heightOfView;
    Thread animeThread=null;
    static int widthOfView;
    long sleep = 30;
    Circle obj=new Circle();
    Paint p1 = new Paint();
    public CircleView(Context context, AttributeSet attrs) {
        super(context, attrs);
       bounceCircle(sleep);

    }

    @Override
    protected void onDraw(Canvas canvas) {
        p1.setStyle(Paint.Style.STROKE);
         for(Circle obj:pointList)
        {
            canvas.drawCircle(obj.getCenterX(), obj.getCenterY(), obj.getRadius(), obj.getColorSelected());

        }
//        if(modeOfCircle=="Move")
//        {
//            for(Circle obj2: pointList)
//            canvas.drawCircle(obj2.getCenterX(),obj2.getCenterY(),obj2.getRadius(),obj2.getColorSelected());
//        }
        invalidate();
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec) {
        super.onMeasure(widthMeasureSpec, heightMeasureSpec);
        heightOfView=View.MeasureSpec.getSize(heightMeasureSpec);
        widthOfView=View.MeasureSpec.getSize(widthMeasureSpec);
    }

    public void run()
    {
        boolean flag= true;
        try {


            while (flag) {
                for (Circle obj : pointList) {
                    obj.animate();
                }
                postInvalidate();
                Thread.sleep(sleep);
            }
        }
        catch(Exception e)
        {
            System.out.println(e);
        }

    }

    public void bounceCircle(long h)
    {

        animeThread=new Thread(this);
        animeThread.start();
    }
}


